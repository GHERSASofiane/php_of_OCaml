let f () =
     while true do
    	print_string "bla"
  done;;