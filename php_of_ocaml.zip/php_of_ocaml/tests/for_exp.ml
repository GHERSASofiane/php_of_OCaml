for i=10 downto 1 do
    print_string "hello ";
  done;;