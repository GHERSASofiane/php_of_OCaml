print_char 'a';;
print_newline () ;;
print_int 200;;
print_newline () ;;
print_float 20.5;;
print_newline () ;;
print_endline "Salut tout le monde __ Avec retour a la ligne" ;;
print_string "Salut tout le monde";;