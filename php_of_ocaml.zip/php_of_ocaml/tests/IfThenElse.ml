(* 
if 5<3 then 2 else 4;;

if true then 1 else 0;; *)
let x = ref 0 in
if true then  x := 8 else  x := 9 




