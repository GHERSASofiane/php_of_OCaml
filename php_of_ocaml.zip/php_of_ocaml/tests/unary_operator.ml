min 5 10 ;;
max 5 10 ;;
not true ;; 
true  &&  false;; 
true  &&  false;; 
true  || false;;  
succ 10;; (* ++10  *)
pred 10;; (* --10  *)
10 mod 5 ;;
abs (-20);;
4. ** 2. ;;
"GHERSA" ^ " Sofiane";;
cos 2. ;;
sin 2. ;;
tan 2. ;;
log 2. ;;
log10 2. ;;
sqrt 2. ;;
exp 2. ;;
(* 
expm1
log1p
cos
sin
tan
acos
asin
atan
atan2
hypot
cosh
sinh
tanh
ceil
floor
abs_float
copysign
mod_float
frexp
ldexp
modf
float
float_of_int
truncate
int_of_float
infinity
neg_infinity
nan
epsilon_float *)


(*
max_int;;
min_int;;
max_float;;
min_float;; 
land
lor
lxor
lnot
lsl
lsr
asr

*)
