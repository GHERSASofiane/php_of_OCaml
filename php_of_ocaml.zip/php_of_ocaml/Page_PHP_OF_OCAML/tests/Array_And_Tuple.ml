let tab_vide = [||]
let tab_int = [|4;6;87|]
let tab_float = [|4.4;6.5;8.7;0.5|]
let tab_char = [|'a';'b';'c';'d'|]
let tab_string = [|"GHERSA";"Sofiane";"KASDI";"Hacene"|]

let tup_1_elem = ( 88)
let tup_2_elem = ( 'a', "ocaml")
let tup_3_elem = ( 'a', "ocaml", 20)
let tup_4_elem = ( 88, 5.20, 'a', "ocaml")