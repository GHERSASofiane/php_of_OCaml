<?php


 if( 5 < 3 ) {
 	   echo 2 ;
	  echo '<br>';
 }else{
 	   echo 4 ;
	  echo '<br>';
 }

 if( true  ) {
 	  echo 1 ;
	  echo '<br>';
 }else{
 	  echo 0 ; 	  
	  echo '<br>';
 }

?>
