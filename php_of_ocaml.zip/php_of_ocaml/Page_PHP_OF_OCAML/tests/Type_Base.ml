let notre_int = 5 ;;(* entier *)
let notre_char = 'C' ;;(* caractère *)
let notre_string = "notre string en OCAML qui traduit en PHP" ;;(* chaîne de caractère *)
let notre_float = 10.5 ;;(* réel *)