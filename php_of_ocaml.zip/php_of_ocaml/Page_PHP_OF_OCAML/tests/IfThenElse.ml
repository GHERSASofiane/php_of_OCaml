
if 5<3 then 2 else 4;;

if true then 1 else 0;;




