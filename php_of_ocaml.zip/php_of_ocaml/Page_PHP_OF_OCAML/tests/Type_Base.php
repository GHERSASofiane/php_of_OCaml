<?php


 $notre_int = 5;

 $notre_char = 'C';

 $notre_string = "notre string en OCAML qui traduit en PHP";

 $notre_float = 10.5;

 echo $notre_int.'<br>';
 echo  $notre_char.'<br>';
 echo $notre_string.'<br>';
 echo  $notre_float.'<br>';
?>
